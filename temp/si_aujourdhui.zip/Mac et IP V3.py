# Python Program to compute
# MAC address of host
# using UUID module

import re, uuid

# printing the value of unique MAC
# address using uuid and getnode() function
print (hex(uuid.getnode()))



# Python 3 code to print MAC
# in formatted way.

# joins elements of getnode() after each 2 digits.

print ("L'adresse @Mac dans son format est : ", end="")
print (':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
for ele in range(0,8*6,8)][::-1]))


# Python 3 code to print MAC
# in formatted way and easier
# to understand

# Python Program to Get IP Address
import socket
hostname = socket.gethostname()
IPAddr = socket.gethostbyname(hostname)
print("Le Nom de votre PC est:" + hostname)
print("L'adresse IP V4 de votre PC est :" + IPAddr)

