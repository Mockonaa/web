# importing ip_network from ipaddress module
from ipaddress import ip_network

def sameNetwork(IP1: str, IP2: str) -> str:
    a = ip_network(IP1, strict = False).network_address
    b = ip_network(IP2, strict = False).network_address
    if(a == b) :
        return "Les 2 adresses sont sur le même réseau, elles peuvent communiquer entre elles !"
    else :
        return "Les 2 adresses ne sont pas sur le même réseau => pas de comminication possible !"

ad1 =input("donner l'adresse de la machine 1 (ex classe C: 192.168.1.12/24 <= adresse IP de Masquer de Sous Réseau 255.255.255.0) :")
AD1=str(ad1)

ad2 =input("donner l'adresse de la machine 2 (ex classe A: 10.189.43.20/8 <= adresse IP de Masquer de Sous Réseau 255.0.0.0) :")
AD2=str(ad2)

print(sameNetwork(AD1, AD2))


  

