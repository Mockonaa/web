import socket # Aller chercher les caractéristiques de l'ordinateur
from scapy.all import Ether # Aller chercher le protocole utilisé TCP IP
import ipaddress

nom_PC = socket.gethostname() # stocker le nom de l'ordinateur   
IP_Addr = socket.gethostbyname(nom_PC) # stocker l'adresse IP de l'ordinateur
mac = Ether().src
network = ipaddress.IPv4Network("192.168.1.0/24")

# Afficher le nom de l'ordinateur
print("le nom de votre ordinateur est : " + nom_PC)
# Afficher son adresse @Mac
print("Son adresse @Mac est : " + mac)
# Déterminer la classe du réseau
if network.num_addresses == 2**8 :
    print("C'est un réseau de classe C")
    print("Le Net ID (nb de réseaux possibles) : ",2**21)    # indique le Net ID
    print("Le Host ID (nb de machines possibles) : ", 2**8)  # Indique le Host ID
elif network.num_addresses == 2**16 :
    print("c'est un réseau de classe B")
    print("Le Net ID (nb de réseaux possibles) : ",2**14)    # indique le Net ID
    print("Le Host ID (nb de machines possibles) : ", 2**16)  # Indique le Host ID
elif network.num_addresses == 2**24 :
    print("c'est un réseau de classe A")
    print("Le Net ID (nb de réseaux possibles) : ",2**7)    # indique le Net ID
    print("Le Host ID (nb de machines) : ", 2**24)  # Indique le Host ID
# Afficher son adresse IP   
print("Son adresse IPv4 est : " + IP_Addr)
# Obtenir le masque de sous réseau
print("Son masque de sous réseau est : ", network.netmask)
# obtenir l'adresse de diffusion (dernière adresse prise par le réseau)
print("Son adresse de Broadcast (dernière adresse réservée du réseau):", network.broadcast_address)
# obtenir l'adresse de début du réseau
print("Adresse réservée du début de réseau", str(network))
# obtenir le nombre de machines possible sur ce réseau
print("Nombre de machines possibles sur ce réseau : ", network.num_addresses-2)




    
