import socket # Aller chercher les caractéristiques de l'ordinateur
from scapy.all import Ether # Aller chercher le protocole utilisé TCP IP
import ipaddress
import socket
import re, uuid

hostname = socket.gethostname()
IPAddr = socket.gethostbyname(hostname)
print (hex(uuid.getnode()))

nom_PC = socket.gethostname() # stocker le nom de l'ordinateur   
IP_Addr = socket.gethostbyname(nom_PC) # stocker l'adresse IP de l'ordinateur
mac = Ether().src
network1 =0
network2 =0
network3 =0

# Sélectionner la type de réseau : réseau étendu (WAN) ou réseau urbain (MAN) ou réseau local (LAN)
Type_reseau=input("Sélectionner la type de réseau => réseau étendu (WAN) ou réseau urbain (MAN) ou réseau local (LAN) : ")

if Type_reseau =="LAN" :
    #print("c'est un réseau de classe C qu'il vous faut")
    network = ipaddress.IPv4Network("192.168.1.0/24")
    network1= network.num_addresses
    print("L'adresse IP V4 de votre PC est : " + IPAddr)
    print ("Son adresse @Mac est ",':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
    for ele in range(0,8*6,8)][::-1]))
    
elif Type_reseau =="MAN" :
    #print("c'est un réseau de classe B qui vous faut")
    network = ipaddress.IPv4Network("127.0.0.0/16")
    network2= network.num_addresses
    print("L'adresse IP V4 de votre PC est : " + IPAddr)
    print ("Son adresse @Mac est ",':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
    for ele in range(0,8*6,8)][::-1]))
    
elif Type_reseau =="WAN" :
    #print("c'est un réseau de classe A qui vous faut")
    network = ipaddress.IPv4Network("10.189.43.0/24")
    network3= network.num_addresses
    print("L'adresse IP V4 de votre PC est : " + IPAddr)
    print ("Son adresse @Mac est ",':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
    for ele in range(0,8*6,8)][::-1]))

    
    
# Afficher le nom de l'ordinateur
print("le nom de votre ordinateur est : " + nom_PC)

# Déterminer la classe du réseau
if Type_reseau =="LAN" and not Type_reseau =="MAN" and not Type_reseau =="WAN"   :
    #print("Son adresse IPv4 est : " + IP_Addr)
    print("Son masque de sous réseau est : ", network.netmask) # Obtenir le masque de sous réseau
    print("c'est bien un réseau de classe C")
    print("Le Net ID : ",2**21 , "réseaux informatiques")    # indique le Net ID
    print("Le Host ID : ", 2**8 , "nb de machines au total sur votre réseau")  # Indique le Host ID
    print("Nombre de machines possibles sur ce réseau : ", network.num_addresses-2)
    print("Son adresse de Broadcast :", network.broadcast_address, " C'est la dernière adresse réservée pour votre réseau") # obtenir le nombre de machines possible sur ce réseau
    print("Adresse réservée du début de réseau", str(network)) # obtenir l'adresse de début du réseau
    
elif Type_reseau =="MAN" and not Type_reseau =="WAN" and not Type_reseau =="LAN"   :
    #print("Son adresse IPv4 est : " + IP_Addr)
    print("Son masque de sous réseau est : ", network.netmask) # Obtenir le masque de sous réseau
    print("c'est bien un réseau de classe B")
    print("Le Net ID : ",2**14, "réseaux informatiques")    # indique le Net ID
    print("Le Host ID : ", 2**16, "nb de machines au total sur votre réseau")  # Indique le Host ID
    print("Nombre de machines possibles sur ce réseau : ", network.num_addresses-2)
    print("Son adresse de Broadcast :", network.broadcast_address, " C'est la dernière adresse réservée pour votre réseau") # obtenir le nombre de machines possible sur ce réseau
    print("Adresse réservée du début de réseau", str(network)) # obtenir l'adresse de début du réseau
    
elif Type_reseau =="WAN" and not Type_reseau =="MAN" and not Type_reseau =="LAN"  :
    #print("Son adresse IPv4 est : " + IP_Addr)
    #print("Son masque de sous réseau est : ", network.netmask) # Obtenir le masque de sous réseau
    print("c'est bien un réseau de classe A")
    print("Le Net ID : ",2**7, "réseaux informatiques")    # indique le Net ID
    print("Le Host ID : ", 2**24, "C'est le nombre de machines au total sur votre réseau")  # Indique le Host ID
    print("Nombre de machines possibles sur ce réseau : ", (2**24)-2)
    print("Son adresse de Broadcast :", network.broadcast_address, " C'est la dernière adresse réservée pour votre réseau") # obtenir le nombre de machines possible sur ce réseau
    print("Adresse réservée du début de réseau", str(network)) # obtenir l'adresse de début du réseau


    
    








